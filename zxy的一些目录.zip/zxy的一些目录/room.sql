/*
Navicat MySQL Data Transfer

Source Server         : local3307
Source Server Version : 50728
Source Host           : localhost:3307
Source Database       : room

Target Server Type    : MYSQL
Target Server Version : 50728
File Encoding         : 65001

Date: 2019-12-25 19:13:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `room`
-- ----------------------------
DROP TABLE IF EXISTS `room`;
CREATE TABLE `room` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `phoneno` varchar(20) NOT NULL,
  `location` varchar(40) NOT NULL,
  `apartment` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of room
-- ----------------------------
INSERT INTO `room` VALUES ('1', 'admin', '12345678901', '1栋1单元1001', '二室一厅');
INSERT INTO `room` VALUES ('2', 'zxy', '12345655654', '1栋1单元1002', '二室一厅');
